using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gameobjectstat : MonoBehaviour
{
    public int atkdamage;
    public int atkdef;


    // Start is called before the first frame update
 
}
