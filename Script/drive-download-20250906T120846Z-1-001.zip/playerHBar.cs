using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class playerHBar : MonoBehaviour
{
 //   public float health;
 //   public float MaxHealth;
 //   public Image healthB;
 //   public TextMeshProUGUI playerhp;
 //   public playerHealth Phealth;
 //   public Image healthB;
    // Start is called before the first frame update
 //   void Start()
 //   {
 //       Phealth = GetComponent<playerHealth>();
 //       Debug.Log(Phealth.currentHealth);
 //   }

    // Update is called once per frame
 //   void Update()
 //   {
 //       health = Phealth.currentHealth;
 //       MaxHealth = Phealth.maxHealth;
 //       Debug.Log(health);
 //       playerhp.text = health.ToString();
 //       healthB.fillAmount = Mathf.Clamp(health / MaxHealth, 0, 1);
 //   }
}
